<?php

namespace CP\Customquote\Controller\Index;

use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Action\Context;
use CP\Customquote\Model\CustomquoteFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Exception\LocalizedException;


class Post extends \Magento\Framework\App\Action\Action
{
    protected $datetime;
    protected $_modelCustomquoteFactory;

    /**
     * @param Context $context
     * @param CustomquoteFactory $modelCustomquoteFactory
     */
    public function __construct(
        Context $context,
        CustomquoteFactory $modelCustomquoteFactory,        
        \Magento\Framework\Stdlib\DateTime\DateTime $datetime
    ) {
        $this->_modelCustomquoteFactory = $modelCustomquoteFactory;
        $this->datetime = $datetime;
        parent::__construct($context);
    }

    public function execute()
    {
        $model = $this->_modelCustomquoteFactory->create();
        $data = $this->getRequest()->getPost();
        if (isset($data['id'])) {
            $model->load($data['id']);
        }
        
        $newData = array('store_id'=>1,'user_type'=>0,'is_active'=>0,'customer_id'=>0,'customer_email'=>$data['customer_email'],'customer_name'=>$data['customer_name'],'telephone_no'=>$data['telephone_no'],'product_name'=>$data['product_name'],'category'=>$data['category'],'qty'=>$data['qty'],'qty_type'=>$data['qty_type'],'image'=>$data['image'],'created_from'=>'127.0.0.1','updated_from'=>'127.0.0.1','country_code'=>'IN','platform'=>'','created_time'=>$this->datetime->gmtDate(),'update_time'=>$this->datetime->gmtDate(),'status'=>1,'hold_status'=>0);
        
        $model->setData($newData);
        try{
            $model->save();
            $this->messageManager->addSuccessMessage('Customquote has been submitted successfully');
        } catch (LocalizedException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }

        $this->_redirect('customquote');
        return;
    }
}