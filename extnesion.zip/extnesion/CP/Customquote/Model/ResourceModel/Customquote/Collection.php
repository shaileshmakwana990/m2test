<?php
namespace CP\Customquote\Model\ResourceModel\Customquote;
  
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
  
class Collection extends AbstractCollection
{
    protected $_idFieldName = 'id';
    /**
     * Define model & resource model
     */
    /*protected function _construct()
    {
        $this->_init(
            'CP\Customquote\Model',
            'CP\Customquote\Model\ResourceModel\Model'
        );
    }*/
    protected function _construct()
    {
        $this->_init(
            'CP\Customquote\Model\Customquote',
            'CP\Customquote\Model\ResourceModel\Customquote'
        );
    }
}
