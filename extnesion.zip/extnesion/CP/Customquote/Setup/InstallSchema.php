<?php

namespace CP\Customquote\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        $tableName = $installer->getTable('cp_customquote');
        if ($installer->getConnection()->isTableExists($tableName) != true) {
            $table = $installer->getConnection()
                ->newTable($tableName)
                ->addColumn(
                    'id',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => true
                    ],
                    'ID'
                )
                ->addColumn(
                    'store_id',
                    Table::TYPE_INTEGER,
                    11,
                    [],
                    'store_id'
                )
                ->addColumn(
                    'user_type',
                    Table::TYPE_INTEGER,
                    11,
                    [],
                    'user_type'
                )
                ->addColumn(
                    'is_active',
                    Table::TYPE_INTEGER,
                    11,
                    [],
                    'is_active'
                )
                ->addColumn(
                    'customer_id',
                    Table::TYPE_INTEGER,
                    11,
                    [],
                    'customer_id'
                )
                ->addColumn(
                    'customer_email',
                    Table::TYPE_TEXT,
                    255,
                    [],
                    'customer_email'
                )
                ->addColumn(
                    'customer_name',
                    Table::TYPE_TEXT,
                    225,
                    [],
                    'customer_name'
                )
                ->addColumn(
                    'telephone_no',
                    Table::TYPE_TEXT,
                    255,
                    [],
                    'telephone_no'
                )
                ->addColumn(
                    'product_name',
                    Table::TYPE_TEXT,
                    255,
                    [],
                    'product_name'
                )
                ->addColumn(
                    'category',
                    Table::TYPE_INTEGER,
                    11,
                    [],
                    'category'
                )
                ->addColumn(
                    'qty',
                    Table::TYPE_INTEGER,
                    11,
                    [],
                    'qty'
                )
                ->addColumn(
                    'qty_type',
                    Table::TYPE_INTEGER,
                    11,
                    [],
                    'qty_type'
                )
                ->addColumn(
                    'image',
                    Table::TYPE_TEXT,
                    255,
                    [],
                    'image'
                )                
                ->addColumn(
                    'created_from',
                    Table::TYPE_TEXT,
                    255,
                    [],
                    'created_from'
                )                
                ->addColumn(
                    'updated_from',
                    Table::TYPE_TEXT,
                    255,
                    [],
                    'updated_from'
                )                
                ->addColumn(
                    'country_code',
                    Table::TYPE_TEXT,
                    255,
                    [],
                    'country_code'
                )
                ->addColumn(
                    'platform',
                    Table::TYPE_TEXT,
                    255,
                    [],
                    'platform'
                )
                ->addColumn(
                    'created_time',
                    Table::TYPE_DATETIME,
                    null,
                    [],
                    'created_time'
                )
                ->addColumn(
                    'update_time',
                    Table::TYPE_DATETIME,
                    null,
                    [],
                    'update_time'
                )
                ->addColumn(
                    'status',
                    Table::TYPE_SMALLINT,
                    null,
                    ['nullable' => false, 'default' => '0'],
                    'Status'
                )
                ->addColumn(
                    'hold_status',
                    Table::TYPE_SMALLINT,
                    null,
                    ['nullable' => false, 'default' => '0'],
                    'hold_status'
                )
                ->setComment('CP Customquote')
                ->setOption('type', 'InnoDB')
                ->setOption('charset', 'utf8');
            $installer->getConnection()->createTable($table);
        }

        $installer->endSetup();
    }
}