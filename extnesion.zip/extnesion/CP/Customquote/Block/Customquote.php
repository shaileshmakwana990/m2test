<?php

namespace CP\Customquote\Block;

class Customquote extends \Magento\Framework\View\Element\Template
{
    protected $_helper;
    protected $eavConfig;

    public function __construct(
    	\Magento\Framework\View\Element\Template\Context $context,
        \CP\Customquote\Helper\Data $helper,
        \Magento\Eav\Model\Config $eavConfig,
        array $data = []
    	)
    {
        $this->_helper = $helper;
        $this->eavConfig = $eavConfig;
        parent::__construct($context, $data);
        //parent::__construct($context);
    }

    public function getCategoryCollection()
    {
        return $this->_helper->getCategoryCollectionData();
    }

    public function getFormAction()
    {
        return $this->getUrl('customquote/index/post');
    }
    
    public function toOptionArray()
    {
        return $this->_helper->toOptionCityData();
    }

    public function getQtyUnitOptions(){
        $attribute = $this->eavConfig->getAttribute('catalog_product', 'quantity_unit');
        $options = $attribute->getSource()->getAllOptions();
        return $options;
    }
}
//customquote_record_grid_list